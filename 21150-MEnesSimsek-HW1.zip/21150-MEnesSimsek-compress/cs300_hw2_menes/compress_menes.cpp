#include <iostream>
#include <string>
#include <vector>
#include <fstream>
#include <sstream>
#include <set> 

using namespace std;

/**
 * M. Enes ��M�EK, 21150
*/

template <class Comp, class IntV>
struct TreeNode {

	pair<Comp, IntV> treeElement;
	TreeNode *left;
	TreeNode *right;

	TreeNode(Comp stringKey, IntV intValue): treeElement(stringKey, intValue){
		left = NULL;
		right = NULL;
	}
	TreeNode():  left(NULL), right(NULL) {}
};

template <class Comp, class IntV>
class Binary_Search_Tree {
private:
	TreeNode<Comp, IntV> * root;

	void newNodeToTree(TreeNode<Comp, IntV> *ptr, Comp strVal, IntV intVal) {
		if(ptr->treeElement.first > strVal){
			TreeNode<Comp, IntV> *childptr = ptr->left; //take the child ptr to the left.

			if(childptr != NULL){
				newNodeToTree(childptr, strVal, intVal);
			}
			else{
			
				ptr->left = new TreeNode<Comp, IntV>(strVal, intVal);
			}

		}
		else if(ptr->treeElement.first < strVal){
			TreeNode<Comp, IntV> *childptr = ptr->right; //this time right

			if(childptr != NULL){
				newNodeToTree(childptr, strVal, intVal);
			}
			else{
			
				ptr->right = new TreeNode<Comp, IntV>(strVal, intVal);
			}
		}
		else
			return; //Duplicate
	}

	int searchForInt (TreeNode<Comp, IntV> *ptr, Comp strVal){

		if(ptr->treeElement.first > strVal){
			TreeNode<Comp, IntV> *childptr = ptr->left;

			if(childptr != NULL){
				return searchForInt(childptr, strVal);
			}
			else{
				return -1; //does not exist
			}

		}
		else if(ptr->treeElement.first < strVal){
			TreeNode<Comp, IntV> *childptr = ptr->right;

			if(childptr != NULL){
				return searchForInt(childptr, strVal);
			}
			else
				return -1; //not found

		}
		else
			return ptr->treeElement.second; //found the int
	}

public:

	Binary_Search_Tree(): root(NULL) {}

	void newToRoot(Comp strVal, IntV intVal){
		if(root == NULL){
			root = new TreeNode<Comp, IntV>(strVal, intVal);
		}
		else
			newNodeToTree(root, strVal, intVal);
	}
	int searchForIntPublic(Comp strVal){
		if(root == NULL)
			return -1; //which means it does not exist.
		else
			return searchForInt(root, strVal);
	}
};

Binary_Search_Tree<string, int> BST;

bool isSeenSoFar(char c, vector<char> charArr){

	for(int y = 0; y < charArr.size(); y++){
		if(c == charArr[y]){
			return true;
		}
	}
	return false;
}

string getString(char x) 
{ 
    string s(1, x); 
  
    return s;    
} 

int main() {


	ifstream input("compin.txt");
	ofstream output("compout.txt");

	string compinText = static_cast<stringstream const&>(stringstream() << input.rdbuf()).str();
	static int wantedLength = 2; //generate only once
	
	//set<string> charSet;
	//get unique chars
	/*for(int i = 0; i < compinText.length(); i++){
		charSet.insert(getString(compinText[i]));
	}*/

	//Initialize the tree in the following.
	/*for(auto f : charSet) {
		BST.newToRoot(f, initialCode++);
	}*/

	
	static int code = 0;
	string keyValue;

	int i = 0;
	while(i < 256) { //initialize it for ASCII chars.
		keyValue = code;
		BST.newToRoot(keyValue,code++);
		i++;
	}



	static int initialCode = 256; 
	while(compinText.length() >= wantedLength){
		string inputText = compinText.substr(0, wantedLength);
		int locationOfText = BST.searchForIntPublic(inputText);

		if(locationOfText == -1){
			BST.newToRoot(inputText, initialCode);
			output<< BST.searchForIntPublic(compinText.substr(0, wantedLength - 1));

			output<< " ";
			compinText = compinText.substr(wantedLength - 1);
			wantedLength = 2;
			initialCode++;
		}
		else
			wantedLength++;
	}

	if(compinText.length() > 0) {
		output<< BST.searchForIntPublic(compinText);
	}
	output<<" ";
	output.close();




	//cin.get(); for speed.
	//cin.ignore(); 
	return 0;
}
