#include <iostream>
#include <string>
#include <fstream>

using namespace std;

string Limit[4096];
void concatenater (int nextChar, string & alreadyDecoded);

unsigned index = 256;


string findCorresponding(int preChar, int nextChar){
	
	string toBeDecoded = Limit[preChar];

	concatenater(nextChar, toBeDecoded);

	Limit[index] = toBeDecoded;
	index++;

	return Limit[nextChar];
}

void concatenater (int nextChar, string & alreadyDecoded){

	if(Limit[nextChar] == ""){
		alreadyDecoded += alreadyDecoded[0];
	}
	else{
		if(Limit[nextChar] != ""){
			alreadyDecoded += Limit[nextChar][0];
		}
		else
			alreadyDecoded = "";
	}

}


int main()
{
	//index = 256;

	for (int i = 0; i < index; i++){
		Limit[i] = i;
	}

	ifstream input("compout.txt");
	ofstream output("decompout.txt");

	//process the first char
	//to create continuation

	int codeIn;
	//take only one
	input >> codeIn;

	output<<Limit[codeIn];

	int codeContd;

	while(input>> codeContd){
		output<< findCorresponding(codeIn, codeContd);
		codeIn = codeContd;
	}

	return 0;
}
