#include <iostream>
#include <string>
#include <fstream>
#include <vector>
#include <cstdlib>

using namespace std;

/*
 * M. Enes ��M�EK	
 * 21150
 * CS300 - HW3
 */


int passValue = -2;

/*
* C++ Program to Implement Hash Tables with Linear Probing
*/
const int TABLE_SIZE = 5003; //initial declaration of integer to manipulate the table size.
/*
* HashNode Class Declaration
*/
class HashNode
{
public:
	int key;
	int value;
	HashNode(int key, int value)
	{
		this->key = key;
		this->value = value;
	}
};

/*
* DeletedNode Class Declaration, to distinguish whether a node is deleted or just empty (never been inserted)
*/
class DeletedNode: public HashNode
{
private:
	static DeletedNode *entry;
	DeletedNode():HashNode(-1, -1) {}
public:
	static DeletedNode *getNode()
	{
		if (entry == NULL)
			entry = new DeletedNode();
		return entry;
	}
};
DeletedNode *DeletedNode::entry = NULL;
/*
* HashMap Class Declaration
*/
class HashMap
{
private:
	HashNode **htable;
	int probeNumber;
public:
	HashMap()
	{
		htable = new HashNode* [TABLE_SIZE];
		for (int i = 0; i < TABLE_SIZE; i++)
		{
			htable[i] = NULL;
		}
	}

	~HashMap()
	{
		for (int i = 0; i < TABLE_SIZE; i++)
		{
			if (htable[i] != NULL && htable[i] != DeletedNode::getNode())
				delete htable[i];
		}
		delete[] htable;
	}
	/*
	* Hash Function
	*/
	int HashFunc(int key)
	{
		return key % TABLE_SIZE;
	}
	/*
	* Insert Element at a key
	*/
	bool insert_with_key_and_value(/*int key, */int value)
	{
		int hash_val = HashFunc(/*key*/value);
		int key = hash_val;

		int init = -1;
		int deletedindex = -1;
		probeNumber = 0;

		while (hash_val != init && (htable[hash_val] == DeletedNode::getNode() || htable[hash_val] != NULL && htable[hash_val]->key != key))
		{
			if (init == -1)
				init = hash_val;
			if (htable[hash_val] == DeletedNode::getNode())
				deletedindex = hash_val;
			hash_val = HashFunc(hash_val + 1);
			probeNumber++;
		}
		if (htable[hash_val] == NULL || hash_val == init)
		{
			if(deletedindex != -1){
				htable[deletedindex] = new HashNode(deletedindex, value);
				return true;
			}

			else{
				htable[hash_val] = new HashNode(hash_val, value);
				return true;
			}
		}
		if(init != hash_val)
		{
			if (htable[hash_val] != DeletedNode::getNode())
			{
				while (htable[hash_val] != NULL)
				{

					if(htable[hash_val]->value != value){
						hash_val = HashFunc(hash_val + 1);
						probeNumber++;
						if(htable[hash_val] == NULL){

							htable[hash_val] = new HashNode(hash_val, value);
							return true;
						}

						else if (htable[hash_val] != NULL && htable[hash_val]->key == key)
							return false;
						else
							continue;
					}
					else
						return false; //duplicate value.
				}


			}
			else{
				htable[hash_val] = new HashNode(key, value);
				return true;
			}
		}
	}

	int getProbeNumber(){
		return probeNumber;
	}

	/*
	* Search Element at a key
	*/
	int search_with_key(int key)
	{
		int hash_val = HashFunc(key);
		int init = -1;
		probeNumber = 0;

		while (hash_val != init && (htable[hash_val] == DeletedNode::getNode() || htable[hash_val] != NULL && htable[hash_val]->value != key))
		{
			if (init == -1)
				init = hash_val;
			hash_val = HashFunc(hash_val + 1);
			probeNumber++;
		}
		if (htable[hash_val] == NULL || hash_val == init){
			//probeNumber = TABLE_SIZE; //if cannot be found, than probeNumber is M.
			return -1;
		}
		else
			return htable[hash_val]->key;
	}

	/*
	* Remove Element at a key
	*/
	bool remove_with_key(int key)
	{
		int hash_val = HashFunc(key);
		int init = -1;
		probeNumber = 0;
		while (hash_val != init && (htable[hash_val] == DeletedNode::getNode() || htable[hash_val] != NULL && htable[hash_val]->value != key)  )
		{
			if (init == -1)
				init = hash_val;
			hash_val = HashFunc(hash_val + 1);
			probeNumber++;
		}
		if (hash_val != init && htable[hash_val] != NULL)
		{
			delete htable[hash_val];
			htable[hash_val] = DeletedNode::getNode();
			return true;
		}
		else
			return false;
	}

	void display_hash_table(){
		for(int i = 0; i < TABLE_SIZE; i++){
			if(htable[i] != NULL && htable[i]->key != -1) 
				cout <<"Index "<<i<<" is: key = " << htable[i]->key <<"  value = "<< htable[i]->value << endl;
			else
				cout<<"Index " << i << " is empty and/or deleted."<<endl;
		}
	}
};

struct node{
	int numProbe;
	int iteration;
	bool isManipulated;

	node(int numProbe1, int iteration1, bool isManipulated1){ //iteration is total numbe rof probes.
		numProbe = numProbe1;
		iteration = iteration1;
		isManipulated = isManipulated1;
	}
	node(){

	}
};


void initializeArray (vector<node> &arrayToInitialize){
	arrayToInitialize.reserve(TABLE_SIZE+1);

	for(int i = 0; i < TABLE_SIZE + 1; i++){
		node tmp(0, 0, false);
		arrayToInitialize.push_back(tmp);
	}

	/*
	for(int i = 0; i < arrayToInitialize.size(); i++){
		arrayToInitialize.at(i).iteration = 0;
		arrayToInitialize.at(i).numProbe = 0;
	}
	*/
}

int main(){

	HashMap hash;

	//int insertOp = 6, deleteOp = 1, findOp = 1;
	
	//int insertOp = 4, deleteOp = 2, findOp = 2;

	int insertOp = 2, deleteOp = 1, findOp = 5;

	ofstream output("data3.csv");


	int totalSuccessfulInsert = 0;
	int totalUnsuccessfulInsert = 0;
	int totalSuccessfulDelete = 0;
	int totalUnsuccessfulDelete = 0;
	int totalSuccessfulFind = 0;
	int totalUnsuccessfulFind = 0;


	int totalTransactionGeneration = 0;
	int totalProbeNumber = 0;

	int N = 0; //initially total inserted values are 0.
	double L = 0; //initially lambda is zero.

	vector<node> probingArrayUnsInsert;
	vector<node> probingArrayDelete;
	vector<node> probingArrayUnsDelete;
	vector<node> probingArrayFind;
	vector<node> probingArrayUnsFind;
	vector<node> probingArrayInsert;
	
	initializeArray(probingArrayInsert);
	initializeArray(probingArrayUnsInsert);
	initializeArray(probingArrayDelete);
	initializeArray(probingArrayUnsDelete);
	initializeArray(probingArrayFind);
	initializeArray(probingArrayUnsFind);
	
	vector<double> lambdaValues;

	while(totalTransactionGeneration <= 1000000 && TABLE_SIZE != totalSuccessfulInsert){

		int tmp = rand() % 8;

		totalTransactionGeneration++;

		L = (double) N/TABLE_SIZE;

		int randomNumber2 = rand() % (10*TABLE_SIZE);

		if(0 <= tmp && tmp <= insertOp - 1){
			if(hash.insert_with_key_and_value(randomNumber2)){

				totalSuccessfulInsert++;
				N++;
				lambdaValues.push_back(L);

				probingArrayInsert.at(N).iteration++;
				probingArrayInsert.at(N).numProbe += hash.getProbeNumber();
				probingArrayInsert.at(N).isManipulated = true;
			}
			else
			{
				totalUnsuccessfulInsert++;
				lambdaValues.push_back(L);

				probingArrayUnsInsert.at(N).iteration++;
				probingArrayUnsInsert.at(N).numProbe += hash.getProbeNumber();
				probingArrayUnsInsert.at(N).isManipulated = true;
			}
		}
		else if(insertOp <= tmp && tmp <= insertOp + deleteOp - 1){

			if(hash.remove_with_key(randomNumber2)){
				totalSuccessfulDelete++;
				N--;
				lambdaValues.push_back(L);

				probingArrayDelete.at(N).iteration++;
				probingArrayDelete.at(N).numProbe += hash.getProbeNumber();
				probingArrayDelete.at(N).isManipulated = true;
			}
			else
			{
				totalUnsuccessfulDelete++;
				lambdaValues.push_back(L);

				probingArrayUnsDelete.at(N).iteration++;
				probingArrayUnsDelete.at(N).numProbe += hash.getProbeNumber();
				probingArrayUnsDelete.at(N).isManipulated = true;
			}

		}
		else{


			if(hash.search_with_key(randomNumber2) != -1){
				totalSuccessfulFind++;
				lambdaValues.push_back(L);

				probingArrayFind.at(N).iteration++;
				probingArrayFind.at(N).numProbe += hash.getProbeNumber();
				probingArrayFind.at(N).isManipulated = true;
			}
			else
			{
				totalUnsuccessfulFind++;
				lambdaValues.push_back(L);

				probingArrayUnsFind.at(N).iteration++;
				probingArrayUnsFind.at(N).numProbe += hash.getProbeNumber();
				probingArrayUnsFind.at(N).isManipulated = true;
			}

		}
	}
	
	vector<vector<node>> arrayOfArray;

	arrayOfArray.push_back(probingArrayInsert);
	arrayOfArray.push_back(probingArrayUnsInsert);
	arrayOfArray.push_back(probingArrayDelete);
	arrayOfArray.push_back(probingArrayUnsDelete);
	arrayOfArray.push_back(probingArrayFind);
	arrayOfArray.push_back(probingArrayUnsFind);

	cout<< "LAMBDA VALUES SIZE IS:" << lambdaValues.size()<<endl;
	for(int m = 0; m < lambdaValues.size(); m++){
		output<< lambdaValues[m];
		output<<";";
	}
	output<<endl;

	for(int j = 0; j < arrayOfArray.size(); j++){
		vector<node> tmp = arrayOfArray[j];
		for(int y = 0; y < tmp.size(); y++){
			node tmp2 = tmp[y];
			if(tmp2.isManipulated == true){
				output<< (double) tmp2.numProbe / tmp2.iteration;
				output<< ";";
			}
			else
			{
				output<< ";";
			}
		}
		output<<endl;
	}

	output.close();

	//cin.get();
	//cin.ignore();
	return 0;
}
