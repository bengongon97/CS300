#include <iostream>
#include <string>
#include <algorithm>
#include <fstream>
#include <sstream>
#include <vector>

using namespace std;

struct node {
	//my node to store the necessary values.
public:
	int xCoor;
	int yCoor;
	bool isStart;

	node(int xCoor1, int yCoor1, bool isStart1){
		xCoor = xCoor1;
		yCoor = yCoor1;
		isStart = isStart1;	
	}

	bool operator>(const node & cord) const
	{
		return yCoor > cord.yCoor;
	}

};

//class is from slides. I did some necessary improvements.
class BinaryHeap
{
public:
	BinaryHeap(int capacity){
		currentSize = 0;
		initializeArray(myArray, capacity+5);
	};

	/**
	* Insert item x into the priority queue, maintaining heap order.
	* Duplicates are allowed.
	*/
	void insert(node & x)
	{
		int hole = ++currentSize;
		for( ; hole > 1 && x > myArray[ hole / 2 ]; hole /= 2 )
			myArray[ hole ] = myArray[ hole / 2 ];
		myArray[ hole ] = x;
	}

	bool isEmpty(){
		return myArray.size() == 0;
	}

	void makeEmpty(){
		for(unsigned int i = 0; i < myArray.size(); i++){
			myArray.pop_back();
		}
	}

	int getMax(){ //to get the max value stored.
		return myArray[1].yCoor;
	}

	void remove(int toBeRemovedYCoor){
		for(unsigned int i = 0; i < myArray.size(); i++){
			if(myArray[i].yCoor == toBeRemovedYCoor && !isEmpty()){
				myArray.erase(myArray.begin() + i);
				--currentSize; //reduce the stored elements.
				percolateUp(i); //Establish heap order property back.
			}
		}
	}

private:

	int currentSize; // Number of elements in heap
	vector<node> myArray;  // The heap array

	/**
	* Internal method to percolate down in the heap.
	* hole is the index at which the percolate begins.
	*/
	void percolateUp( int hole )
	{
		int child;
		node tmp = myArray[ hole ];

		for( ; hole * 2 <= currentSize; hole = child )
		{
			child = hole * 2;
			if( child != currentSize && myArray[ child + 1 ] > myArray[ child ] )
				child++;
			if( myArray[ child ] > tmp )
				myArray[ hole ] = myArray[ child ];
			else
				break;
		}
		myArray[ hole ] = tmp;
	}

	void initializeArray(vector<node> &arr, int cap){ //initializing the array according to the number read from the file.

		for(int i = 1; i < cap; i++){
			arr.push_back(node(0,0,false));
		}
	}
};

bool comparator (node item1, node item2){ //comparison for std::sort
	return (item1.xCoor < item2.xCoor) || ((item1.xCoor == item2.xCoor) && (item1.yCoor < item2.yCoor));
}

int main(){

	ifstream input;

	input.open("input.txt");

	if(input.fail()) {
		cout<<"Failed to open the file."<<endl; //If I cannot open it :(
		return 0;
	}

	vector<node> nodeVector;

	string firstLineToProcess;
	int totalNumber, zeroChecker = 0;
	getline(input, firstLineToProcess);
	istringstream iss1(firstLineToProcess);
	iss1 >> totalNumber; //getting the number of buildings.

	string lineToProcess;
	int x1coor, ycoor, x2coor;

	while(getline(input, lineToProcess)){ //processsing input file and adding them accordingly
		istringstream iss(lineToProcess);

		iss >> x1coor >> ycoor >> x2coor;

		if(x1coor == 0)
			zeroChecker++;

		node myStartNode(x1coor, ycoor, true);
		node myEndNode(x2coor, ycoor, false);

		nodeVector.push_back(myStartNode);
		nodeVector.push_back(myEndNode);

	}
	
	if(zeroChecker == 0){
		node myZeroNode(0, 0, true);
		nodeVector.push_back(myZeroNode); //just to add a zero element if the buildings do not start from zero.
	}
	
	sort(nodeVector.begin(), nodeVector.end(), comparator);

	//NOW, WE ARE READY TO USE OUR INPUT.

	BinaryHeap heap(totalNumber);

	int M = 0;
	int tmpM = -1;
	//nodeVector.pop_back();
	unsigned int t = 0;
	//nodeVector must be checked to delete the same x values.
	int l = 0;
	while( t < nodeVector.size()-1){
		//t = 0;
		if(nodeVector[l].xCoor == nodeVector[l+1].xCoor){
			
			if(nodeVector[l].yCoor < nodeVector[l+1].yCoor){
				nodeVector.erase(nodeVector.begin() + l);
			}
			else{
				nodeVector.erase(nodeVector.begin() + l + 1);
			}
		 
		}
		else
			l++;
		t++;
	}


	//Process and output accordingly.
	//tmpM is to store the older value of M. (to see whether it is changed)

	for(unsigned int j = 0; j < nodeVector.size(); j++){

		if(nodeVector[j].isStart == true){
			heap.insert(nodeVector[j]);
			M = heap.getMax();

			if(M != tmpM){
				cout<< nodeVector[j].xCoor << " " << M <<endl; //output when M changes.
				tmpM = M;
			}
		}
		else if(nodeVector[j].isStart == false){
			heap.remove(nodeVector[j].yCoor);
			M = heap.getMax();

			if(M != tmpM){
				cout<< nodeVector[j].xCoor << " " << M <<endl; //output when M changes.
				tmpM = M;
			}
		}
	}

	input.close();

	cin.get();
	cin.ignore();
	return 0;
}