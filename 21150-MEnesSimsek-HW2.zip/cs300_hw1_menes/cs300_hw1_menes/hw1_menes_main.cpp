#include <iostream>
#include <string>
#include <sstream>
#include <vector>
#include <fstream>
#include <algorithm>

using namespace std;

/* IMPORTANT NOTE:
 * I USED LINKED LIST DATA STRUCTURE AS MY MAIN IMPLEMENTATION.
 * VECTOR USAGE IN MY PROGRAM IS ONLY IN HAVING THE DOCUMENT NUMBERS AND INTERSECTING THEM.
 * I OBEYED THE RULES WRITTEN IN THE HW1 FILE BY THIS BUT STILL, I WANTED TO LET THE GRADER KNOW. THANK YOU.
 */



struct DownwardsList { //THIS IS WHERE I DEFINE THE DOWNWARDS PART OF THE LINKED LIST.
	int currentIntValue;
	DownwardsList *down;

	DownwardsList (int value){
		currentIntValue = value;
		down = NULL;
	}
};

template<class T>
struct ListOfNodes { //THIS IS MY MAIN LINKED LIST PART (HORIZONTAL PART) IT IS A TEMPLATE STRUCT.

	T currentValue;
	ListOfNodes<T> *head;

	ListOfNodes<T> *next;
	DownwardsList *down; 

	ListOfNodes(T value){ //CONSTRUCTOR
		currentValue = value;
		next = NULL;
		down = NULL;
		head = this;
	}
};

bool isContainingString (ListOfNodes<string> traverseThrough, string query){ //THIS IS TRAVERSAL OF LINKED LIST TO FIND WHETHER THAT STRING EXISTS IN
																			 // IN A GIVEN LINKED LIST.

	ListOfNodes<string> *tmpptr = traverseThrough.head;

	if(tmpptr == NULL){
		cout<<"Error, list is null"<<endl;
	}
	else{

		if(tmpptr -> currentValue == query){
			return true;
		}
		else{
			while (tmpptr -> next != NULL){
				tmpptr = tmpptr -> next;
				if(tmpptr -> currentValue == query){
					return true;
				}
			}
		}

		return false;
	}
}

void insertInside(ListOfNodes<string> insertIn, string strToBeInserted, int docToBeInserted){

	//THIS FUNCTION INSERTS STRINGS AND DOCUMENT NUMBERS TO LINKED LIST.

	ListOfNodes<string> *ptr = insertIn.head;

	while(ptr -> next != NULL){
		ptr = ptr -> next;
	}

	ptr -> next = new ListOfNodes<string>(strToBeInserted);
	ptr -> next -> down = new DownwardsList(docToBeInserted); //INITIALIZATION OF BOTH IS DONE VIA NEW KEYWORD.
}

void insertWhenAlreadyExists(ListOfNodes<string> insertIn, string strToBeInserted, int docToBeInserted){

	//THIS INSERTION FUNCTION IS CALLED ONLY WHEN THE QUERY STRING EXISTS IN THE GIVEN LINKED LIST.
	//THIS IS SEPARATE TO MAKE SURE THAT WE HAVE NO DUPLICATE LINKED LIST MEMBERS.

	ListOfNodes<string> *ptr = insertIn.head;
	DownwardsList *tmp = ptr -> down; 

	if(ptr == NULL){
		cout<<"Error, list is null"<<endl;
	}
	else{

		if(ptr -> currentValue == strToBeInserted){
			while (tmp -> down != NULL){
				tmp = tmp -> down;
			}
			tmp -> down = new DownwardsList(docToBeInserted);
		}
		else{
			while (ptr -> next != NULL){
				ptr = ptr -> next;
				tmp = ptr -> down;
				if(ptr -> currentValue == strToBeInserted){
					while (tmp -> down != NULL){
						tmp = tmp -> down;
					}

					tmp -> down = new DownwardsList(docToBeInserted);
				}
			}
		}

	}

}

vector<int> getTheDocumentNumbersAsVectors(ListOfNodes<string> searchingPlace, string toBeSearchedString){

	// THIS IS TO GET THE DOCUMENT NUMBERS FROM THE LINKED LIST.
	// I STORE THEM IN VECTORS TO INTERSECT AND TO PRINT THEM. 
	// I GET THE INFORMATION COMPLETELY FROM PREVIOUSLY CONSTRUCTED LINKED LIST.

	vector<int> returnedValues;

	ListOfNodes<string> *ptr = searchingPlace.head;
	DownwardsList *tmp = ptr -> down;

	if(ptr == NULL){
		cout<<"Error, list is null"<<endl;
	}
	else{

		if(ptr -> currentValue == toBeSearchedString){
			while(tmp->down != NULL){
				returnedValues.push_back(tmp->currentIntValue);
				tmp = tmp -> down;
			}
			returnedValues.push_back(tmp->currentIntValue);
		}
		else{
			while (ptr -> next != NULL){
				ptr = ptr -> next;
				tmp = ptr -> down;
				if(ptr -> currentValue == toBeSearchedString){
					while (tmp -> down != NULL){
						returnedValues.push_back(tmp->currentIntValue);
						tmp = tmp -> down;
					}
					returnedValues.push_back(tmp->currentIntValue);
				}
			}
		}

		return returnedValues;
	}
}

void deleteBelow(DownwardsList *tmp){

	// THIS IS TO DELETE THE ALL THE DOCUMENT NUMBERS.

	DownwardsList *tmp2 = tmp;
	while(tmp -> down != NULL){
		tmp = tmp -> down;
		delete tmp2;
		tmp2 = tmp;
	}
	if(tmp -> down == NULL && tmp != NULL){
		delete tmp;
		tmp = NULL;
		tmp2 = NULL;
	}
}

void deleteTheLinkedList(ListOfNodes<string> toBeDeleted){
	
	//THIS IS TO REMOVE LINKED LIST FROM HEAP MEMORY.

	ListOfNodes<string> *ptr = toBeDeleted.head;

	ListOfNodes<string> *ptr2 = ptr;
	
	while(ptr2 -> next != NULL && ptr != NULL){
		ptr2 = ptr2 -> next;
		
		deleteBelow(ptr ->down);
		ptr -> head = NULL;
		ptr ->next = NULL;

		ptr = ptr2;
	}
	if(ptr -> next == NULL && ptr != NULL){ //DELETE LAST ELEMENT TOO.
		ptr -> head = NULL;
		ptr -> next = NULL;
		deleteBelow(ptr ->down);
		delete ptr;
		ptr = NULL;
	}
}

vector<int> intersectValue (vector<int> v1, vector<int> v2) {

	//THIS FUNCTION GIVES ME INTERSECTED VALUES FOR TWO QUERY RESULTS THAT ARE STORED IN TWO DIFFERENT VECTORS.

	vector<int> returningVector;

	for(int i = 0; i< v1.size(); i++ ){
		for(int j = 0; j< v2.size(); j++){
			if(v1[i] == v2[j]){
				returningVector.push_back(v1[i]);
			}
		}
	}
	return returningVector;
}

inline string& rtrim(string& s, const char* t = " \t\n\r\f\v")
{
	//THIS IS TO TRIM THE WHITE SPACE AT THE END OF A STRING.

	s.erase(s.find_last_not_of(t) + 1);
	return s;
}

int main() {

	// MAIN FUNCTION

	ifstream fileToRead;
	string nameOfTheFile;

	cout<< "Please enter the name of the .txt file:"<<endl;
	cin>>nameOfTheFile; //INPUT FOR FILE NAME AND LATER
	fileToRead.open(nameOfTheFile); //OPENING IT.

	string lineToProcess;


	if(fileToRead.fail()) {
		cout<<"Failed to open the file."<<endl; //IF OPENING FAILED.
	}
	else if (fileToRead.is_open()) {

		//FROM HERE...
		string firstLineToProcess;
		getline(fileToRead, firstLineToProcess);

		string nameToStoreFirst;
		int documentNumberFirst;
		istringstream issFirst (firstLineToProcess);
		issFirst >> nameToStoreFirst >> documentNumberFirst;
		
		ListOfNodes<string> myLinkedList(nameToStoreFirst);
		ListOfNodes<string> *headPointer = new ListOfNodes<string>(nameToStoreFirst);
		DownwardsList *downPointer = new DownwardsList(documentNumberFirst);
		myLinkedList.down = downPointer;
		myLinkedList.next = NULL;
		//TO HERE IS TO CONSTRUCT THE FIRST NODE OF THE LINKED LIST.

		while(getline(fileToRead, lineToProcess)) {
			// lineToProcess now has the first line in the file.
			string nameToStore;
			int documentNumber;

			istringstream iss (lineToProcess);


			while(iss >> nameToStore >> documentNumber){ // HERE IS TO ADD THE OTHER NODES OF THE LINKED LIST.

				if(myLinkedList.head != NULL && isContainingString(myLinkedList, nameToStore)){ //IF IT ALREADY EXISTS, PROPER FUNCTION IS CALLED.
					insertWhenAlreadyExists(myLinkedList, nameToStore, documentNumber);
				}

				else if(myLinkedList.head != NULL && !isContainingString(myLinkedList, nameToStore)){ // IT IS NOT INSIDE, INSERT IT.
					insertInside(myLinkedList,nameToStore,documentNumber);
				}

				else{
					cout<<"Check your input file, perhaps it does not contain proper output!"<<endl; // SOMETHING WRONG IS GOING ON.
				}
			}
		}

		int queryNumber;

		cout<<"Enter a query in expected format."<<endl;
		cin>>queryNumber;

		if(queryNumber == 0){
			cout<<"You have entered no query. Try again later."<<endl; //IF 0 ENTERED, TERMINATE THE EXECUTION.
			cin.get();
			cin.ignore();
			return 0;
		}

		string words;
		vector<vector<int>> vectorOfvectors;
		string wordListstring = "";

		for(int o = 0; o < queryNumber; o++){ //GET STRINGS FROM USER INPUT AS MUCH AS THE QUERY NUMBER.
			cin>>words;
			wordListstring += words + " ";
		}

		rtrim(wordListstring); //TRIM THE TRAILING SPACES.

		istringstream iss1(wordListstring);
		string word;

		while(iss1 >> word)
		{
			vector<int> trial = getTheDocumentNumbersAsVectors(myLinkedList,word); //GET THE QUERIES.
			sort( trial.begin(), trial.end() ); //SORT THE QUERIES FOR EASIER PRINT-OUT.
			trial.erase( unique( trial.begin(), trial.end() ), trial.end() ); // REMOVE DUPLICATES!!! IF TWO LINES ARE SOMEHOW SAME, I GET RID OF THEM HERE!
			vectorOfvectors.push_back(trial);
		}

		vector<int> resultVector;
		if(vectorOfvectors.size() != 0){ // HERE, I AM JUST UNRAVELING MY VECTOR OF VECTORS. FIRST TIME IS CALLED DIFFERENTLY. (SEE ELSE)
			for(int y = 0; y < vectorOfvectors.size()-1; y++){

				if(y>0){
					resultVector = intersectValue(resultVector,vectorOfvectors[y+1] );

					if(resultVector.size() == 0) {
						//cout<<"No common document, they appear."<<endl;
						sort(resultVector.begin(), resultVector.end());

						cout << wordListstring << " " << resultVector.size()<< " "; //I PRINT THE RESULT OUT AS IN DESIRED FORMAT.
						for (auto const& c : resultVector)
							cout << c << " ";
						cin.get();
						cin.ignore();
						return 0;
					}
				}
				else{
					resultVector = intersectValue(vectorOfvectors[y], vectorOfvectors[y+1]); //HERE IS THE SAME BUT IF IT IS THE FIRST TIME.
				}
			}


			sort(resultVector.begin(), resultVector.end()); //FINALLY, TO BE ON THE SAFE SIDE, I SORT IT AGAIN.

			cout << wordListstring << " " << resultVector.size()<< " ";
			for (auto const& c : resultVector)
				cout << c << " "; //I PRINT IT OUT FOR THE INTERSECTED INPUTS IN A DESIRED FORMAT.
		}
		else{
			cout<<"vectorOfVectors is empty."<<endl; //ERROR
		}

		fileToRead.close(); //CLOSE THE FILE.

		deleteTheLinkedList(myLinkedList);
		cin.get();

		cin.ignore();
		return 0;
	}
}